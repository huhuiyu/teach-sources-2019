D:\server\nginx-1.20.1\nginx -c nginx.conf
