D:\server\nginx-1.20.1\nginx -s stop -c nginx.conf
